# EAT NSU Food Ordering System

web site link - https://eatnsu01.000webhostapp.com/

How To Install -
---------

1. Create Database mydb.
2. Run mydb.sql script provided in sql folder.
3. Go to user_login.php and try out our application. Sample user credentials can be found in tbl_student & tbl_ordermsg table.

Note -
---------
1. This is not ready for PRODUCTION.
2. The username and password of sample users are stored in table `tbl_student`.
3. Only Customers with "Verified" status can place orders using "Cash on Delivery" option.
4. Use that name & email while placing an order, else order won't be successful or use "Cash on delivery" option.
6. What's lacking? Dynamic payment(real payment system) and error reporting lacks in this project. And also one might wish for showing corresponding food item's photo and all that stuff.
