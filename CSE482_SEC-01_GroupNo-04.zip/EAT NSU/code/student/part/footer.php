
<!-- social Section Starts Here -->
<section class="social">
        <div class="container text-center">
            <ul>
                <li>
                    <a href="https://www.facebook.com/NorthSouthUniversity"><img src="https://img.icons8.com/fluent/50/000000/facebook-new.png"/></a>
                </li>
                <li>
                    <a href="https://www.instagram.com/northsouthuniversity/?hl=en"><img src="https://img.icons8.com/fluent/48/000000/instagram-new.png"/></a>
                </li>
                <li>
                    <a href="https://twitter.com/northsouthu?lang=en"><img src="https://img.icons8.com/fluent/48/000000/twitter.png"/></a>
                </li>
            </ul>
        </div>
    </section>
    <!-- social Section Ends Here -->
 <!-- footer Section Starts Here -->
 <section class="footer">
        <div class="container text-center">
            <p>© 1993-2022 North South University. All rights reserved.</p>
        </div>
    </section>
    <!-- footer Section Ends Here -->

</body>
</html>