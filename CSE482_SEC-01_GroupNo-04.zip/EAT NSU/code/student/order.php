<?php include('part/menu.php')?>

<?php
if (isset($_GET['food_id'])) {
    # code...
    $food_id = $_GET['food_id'];

    $sql = "SELECT * FROM tbl_food WHERE id=$food_id";
    $res = mysqli_query($conn, $sql);

    $count = mysqli_num_rows($res);

    if ($count==1) {
        # code...
        $row = mysqli_fetch_assoc($res);
        $title = $row['title'];
        $price = $row['price'];
        $image_name = $row['image_name'];
    }
    else
    {
        header('location:'.SITEURL.'student/index.php');
    }
}
else
{
    header('location:'.SITEURL.'student/index.php');
}
?>

    <!-- fOOD sEARCH Section Starts Here -->
    <section class="food-search">
        <div class="container"style="padding: 100px">
            
            <h3 class="text-center " style="color: #ff6b81;">Fill this form to confirm your order</h3>

            <form action="" method="POST"class="order">
                <fieldset>
                    <legend>Selected Food</legend>

                    <div class="food-menu-img">

                        <?php
                                if($image_name=="")
                                {
                                    echo "<div class='fail'>Image Not added</div>";


                                }
                                else
                                {
                                   ?>
                                    <img src="<?php echo SITEURL; ?>images/food/<?php echo $image_name; ?>" alt="Chicke Hawain Pizza" class="img-responsive img-curve">
                                   <?php
                                }
                                ?>  </div>
    
                    <div class="food-menu-desc">
                        <h3><?php echo $title; ?></h3>
                        <p class="food-price"><?php echo $price; ?>Tk</p>
                        <input type="hidden" name="food" value="<?php echo $title; ?>">
                        <input type="hidden" name="price" value="<?php echo $price; ?>">
                        
                        <div class="order-label">Quantity</div>
                        <input type="number" name="qty" class="input-responsive" value="1" required>
                        
                    </div>

                </fieldset>
                <?php
        
        $curentuser=$_SESSION['user'];
        //Query to Get all Admin
        $sql = " SELECT * FROM tbl_student WHere username= '$curentuser' ";
        //Execute the Query
        $res = mysqli_query($conn, $sql);

        //check whetherthe Query is Executed of Not
        if($res)
        {
           
           if(mysqli_num_rows($res)>0) 
            
           {
               //we have data in database
               while($rows = mysqli_fetch_array($res))
               {
                   //using while loop to get all the data from database
                   //And while loop will run as long as we have data in database
                   //Get individual data
                   $id=$rows['id'];
                   $full_name=$rows['full_name'];
                   $username=$rows['username'];
                   $email=$rows['Email'];


                  
                   //Dispaly the Values in our table
               
               }
           }
           else
           {
               //we do not have data in database
           }
        }
   ?>
                <fieldset>
                    <legend>Delivery Details</legend>
                    <div >Full Name:  <input type="text" name="full_name" value="<?php echo $full_name; ?>"></div>

                    <div >Email: <input type="text" name="email" value="<?php echo $email; ?>"></div>
                    <div ><input type="hidden" name="username" value="<?php echo $curentuser; ?>"></div>


                    <div class="order-label">Description</div>
                    <textarea name="description" rows="5" placeholder="E.g. What you like " class="input-responsive" required></textarea>

                    <input type="submit" name="submit" value="Confirm Order" class="btn btn-primary">
                </fieldset>

            </form>
<?php
if (isset($_POST['submit'])) {

    # code...
    $food = $_POST['food'];
    $price = $_POST['price'];
    $qty = $_POST['qty'];
    $total = $price * $qty;
    $order_date = date("Y-m-d h:i:sa");
    $status = "Ordered";
    $description = $_POST['description'];
    $full_name=$_POST['full_name'];
    $email=$_POST['email'];
    $curentuser=$_POST['username'];

    $sql2 = "INSERT INTO tbl_order SET
     food = '$food',
     price = $price,
     qty = $qty,
     total = $total,
     order_date = '$order_date',
     status = '$status',
    description = '$description'

    ";
    $sql3 = "INSERT INTO tbl_ordermsg SET
    food = '$food',
    price = $price,
    qty = $qty,
    total = $total,
    order_date = '$order_date',
    status = '$status',
    description = '$description',
    full_name= '$full_name',
    email= '$email',
    username='$username'
    
    ";
//echo $sql2; die();
    $res2 = mysqli_query($conn, $sql2);

    if($res2==true)
    {
            $_SESSION['order'] = "<div class='success text-center'> Food ordered Successfully.</div>";   
            header('location:'.SITEURL.'student/index.php');
        }

        else
    {
            
        $_SESSION['order'] = "<div class='success text-center'> Failed  to order Food.</div>";   
        header('location:'.SITEURL.'student/index.php');
    }


    $res3 = mysqli_query($conn, $sql3);
    if($res3==true)
    {
            $_SESSION['order'] = "<div class='success text-center'> Food ordered Successfully.</div>";   
            header('location:'.SITEURL.'student/index.php');
        }

        else
    {
            
        $_SESSION['order'] = "<div class='success text-center'> Failed  to order Food.</div>";   
        header('location:'.SITEURL.'student/index.php');
    }

}


?>
        </div>
    </section>
    <!-- fOOD sEARCH Section Ends Here -->

    <?php include('part/footer.php')?>
