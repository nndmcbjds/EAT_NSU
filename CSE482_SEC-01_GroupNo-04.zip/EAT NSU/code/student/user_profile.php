<?php include('part/menu.php')?>

        <!--Main  Content Section Starts-->
        <div class="main-content" style="text-align: center" >
          <div class= "wrapper">
               <h1> Profile </h1>
               <br>

                <?php
                     $curentuser=$_SESSION['user'];
                     //Query to Get all Admin
                     $sql = " SELECT * FROM tbl_student WHere username= '$curentuser' ";
                     //Execute the Query
                     $res = mysqli_query($conn, $sql);

                     //check whetherthe Query is Executed of Not
                     if($res)
                     {
                        if(mysqli_num_rows($res)>0) 
                         
                        {
                            //we have data in database
                            while($rows = mysqli_fetch_array($res))
                            {
                                //using while loop to get all the data from database
                                //And while loop will run as long as we have data in database
                                //Get individual data
                                $id=$rows['id'];
                                $full_name=$rows['full_name'];
                                $username=$rows['username'];
                                $email=$rows['Email'];


                               
                                //Dispaly the Values in our table
                                ?>        
                                     Full Name:  <?php echo $full_name; ?>
                                     <br>
                                       <br> Email:    <?php echo $email; ?>
                                       <br><br> UserName:  <?php echo $username; ?>
                                       <br>
                                <?php
                            }
                        }
                        else
                        {
                            //we do not have data in database
                        }
                     }
                ?>
                <br>
                <br>

                <a href="<?php echo SITEURL; ?>student/update-password.php?id=<?php echo $id;?>" class="btn-sec">Change Password||   </a>  
                                       <a href="<?php echo SITEURL; ?>student/update-profile.php?id=<?php echo $id;?>" class="btn-sec">Update Profile||  </a>
                                       <a href="<?php echo SITEURL; ?>student/delete-profile.php?id=<?php echo $id;?>" class="btn-danger">Delete Profile||   </a>
       
         </div>   
        </div>
   