<?php include('part/menu.php');?>

<div class ="container text-center">
<div class= "container text-center">
    <h1>Update Profile</h1>

    <br>
    <br>
    <?php
        //get id of seleted 
        $id=$_GET['id'];
        //sql query
        $sql="SELECT * FROM tbl_student WHERE id=$id";
        //excute  query 
        $res=mysqli_query($conn,$sql);
        // check 
        if($res==TRUE)
        {
            $count=mysqli_num_rows($res);
            if($count==1)
            {
               //get the details
        
              $row=mysqli_fetch_assoc($res);
              $full_name=$row['full_name'];
              $username=$row['username'];
              $email=$row['Email'];
            }
            else{ 
                //redirect to    page
                header('location'.SITEURL.'student/user_profile.php');
            }
        }

    ?>
<form action="" method = "POST">
    <table class="tbl-30 container text-center">
<tr>
<td>FullName:</td>
<td> 
    <input type="text" name="full_name" value="<?php echo $full_name; ?>">
</td>

</tr>
<tr>
    <td>UserName:</td>
<td> 
    <input type="text" name="username" value="<?php echo $username; ?>">
</td>

</tr>

</tr>
<tr>
    <td>Email address:</td>
<td> 
    <input type="email" name="email" value="<?php echo $email; ?>">
</td>

</tr>

<tr>
    <td colspan="2">
        <input type ="hidden" name="id" value="<?php echo $id;?>">
        <br>
        <br>
    <input type="submit" name="submit"value="Update " class="btn-sec">
</tr>
</table>
</form>

</div>
</div>
<?php
 // check button is clik or not 
 if(isset($_POST['submit']))
 {
     //echo "Button Clicked";
     //get for update
    $id=$_POST['id'];
    $full_name=$_POST['full_name'];
    $username=$_POST['username'];
    $email=$_POST['email'];

     // sql for update admin 

     $sql="UPDATE  tbl_student SET 
     full_name='$full_name',
     username='$username',
     email='$email'
     WHERE id=$id";
     
     
     //excutaue qurey
     $res=mysqli_query($conn,$sql);
     // check query excutate
     if($res==TRUE)
     {
        $_SESSION['update'] = "<div class='sucess'> Update Profile  Successfully.</div>";
        header('location:'.SITEURL.'student/user_profile.php');
     }
     else{
        // "admin not delete";
        $_SESSION['update'] = "<div class = 'fail'> Failed to Profile Update.Try Again Later . </div>";
        header('location:'.SITEURL.'student/user_profile.php');
    }
 }
?>

<?php include('part/footer.php');?>