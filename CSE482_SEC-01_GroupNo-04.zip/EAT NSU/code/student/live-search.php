<?php include('part/menu.php')?>
<!DOCTYPE html>
<html>
<head>
<script>
function showUser(str) {
  if (str=="") {
    document.getElementById("txtHint").innerHTML="";
    return;
  }
  var xmlhttp=new XMLHttpRequest();
  xmlhttp.onreadystatechange=function() {
    if (this.readyState==4 && this.status==200) {
      document.getElementById("txtHint").innerHTML=this.responseText;
    }
  }
  xmlhttp.open("GET","getuser.php?q="+str,true);
  xmlhttp.send();
}
</script>
</head>
<body>

<form>
    <!-- fOOD sEARCH Section Starts Here -->
    <section class="food-search text-center">
        <div class="container">
            
            <form action="<?php echo SITEURL; ?>student/getuser.php" method="POST">
            <div name="users" onchange="showUser(this.value)">
            <input type="search" name="search" placeholder="Search for Food.." required>
            
            <input type="submit" name="submit" value="Search" class="btn btn-primary">
</div>
  
            </form>

        </div>
    </section>
    <!-- fOOD sEARCH Section Ends Here -->


<br>
<div class='fail' id="txtHint"><b>Please Search First.</b></div>

</body>
</html>
