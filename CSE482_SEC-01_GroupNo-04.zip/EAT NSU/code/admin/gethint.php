<!DOCTYPE html>
<html>
<head>
<style>
table {
  width: 100%;
  border-collapse: collapse;
}

</style>
</head>
<body>

<?php
$q = intval($_GET['q']);

$conn = mysqli_connect('localhost','root','');
if (!$conn) {
  die('Could not connect: ' . mysqli_error($con));
}

mysqli_select_db($conn,"mydb");
$sql="SELECT * FROM tbl_student WHERE id = '".$q."'";
$result = mysqli_query($conn,$sql);

echo "<table class='tbl-ful'>
<tr>
         <th>S.N </th>
         <th>FullName </th>
         <th>UserName </th>
         <th>Email </th>
         <th>Action</th>
</tr>";
while($row = mysqli_fetch_array($result)) {
  echo "<tr>";
  echo "<td>" . $row['S.N'] . "</td>";
  echo "<td>" . $row['FullName'] . "</td>";
  echo "<td>" . $row['UserName'] . "</td>";
  echo "<td>" . $row['Email'] . "</td>";
  echo "<td>" . $row['Action'] . "</td>";
  echo "</tr>";
}
echo "</table>";
mysqli_close($conn);
?>
<br>
<br><br><br>
</body>
</html>