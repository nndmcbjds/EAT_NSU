<?php 
        include('../config/constants.php');
        include('login-check.php');

?>

<html>
    <head>
        <title>Eat NSU FOOD ORDER WESITE</title>
        <link rel="stylesheet" href="../css/admin.css">
    </head>

    <body>
        <!--Main Section Starts-->
        <div class="menu text-centre">
        <div class= "wrapper">

        <ul>
         <li> <a href="index.php"> Home</a></li>
            <li> <a href="manage-admin.php"> Admin </a></li>
            <li> <a href="Setting.php"> User list</a></li>
            <li> <a href="manage-category.php"> Category </a></li>
           <li> <a href="manage-food.php"> Food</a></li>
           <li> <a href="manage-order.php"> Order</a></li>
           <li> <a href="logout.php"> Log Out</a></li>
        </ul>

        </div>
        </div>
        <!--Main Section Ends-->