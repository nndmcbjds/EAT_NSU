
<!DOCTYPE html>
<html lang="en">
	<head>
	<meta charset="utf-8">
    <base href="http://www.northsouth.edu/">
    <title>Contact  | North South University</title>
    <meta name="description" content="North South University is the first private university of Bangladesh, was established in 1992">
    <meta name="keywords" content="NSU,North South University,nsu,nsu bd,private university bd,university,bd university">
    <meta name="author" content="North South University">
    <!-- Mobile Specific Metas -->
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
  

    <link rel="icon" type="image/png" href="http://www.northsouth.edu/favicon.png" />
    <link rel="stylesheet" href="newassets/stylesheets/bootstrap.css" type="text/css" />
    <link rel="stylesheet" href="newassets/stylesheets/font-awesome.min.css" type="text/css">
   
    <link rel="stylesheet" href="newassets/stylesheets/owl.carousel.css" type="text/css" />
    <link rel="stylesheet" href="newassets/stylesheets/newstyle.css" type="text/css" />
    <link rel="stylesheet" href="newassets/stylesheets/responsive-utilities.css" type="text/css" />
    
   

		<meta charset="UTF-8" name="viewport" content="width=device-width, initial-scale=1"/>
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-alpha.6/css/bootstrap.min.css">
		<title>Google Map</title>
		<style>
      
      #map {
        height: 70%;
        width: 100%;
        border: 1px solid blue;
      }
     
      html, body {
        height: 100%;
        margin: 0;
        padding: 0;
        font-size: 20px ;
        font-family: Arial, Helvetica, sans-serif;
      
      }
	  h1{
		
		color:Blue;
	  }
    </style>
	</head>
<body>
	
</body>



		<div id="map" ></div>
	</div>
	<div class="page-title full-color" style="display:block;">
         <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="page-title-heading">
                        <center><h1 class="title">Location Map </h1></center>
                    </div>
                </div>
            </div>
            </div>
        </div>
		
            <div class="single body-content">
<div class="container">
<h2 >Contact Number</h2>
				<div class="row">
					<div class="col-md-12">
							<div class="row">
	<div class="col-md-5"> <h5 class="regular">North South University</h5>
                        Bashundhara, Dhaka-1229, Bangladesh
                            <br>
							<i class="fa fa-phone"></i> +880-2-55668200 &nbsp;&nbsp;|&nbsp;&nbsp; <i class="fa fa-fax"></i> Fax: +880-2-55668202
                            <br>
                            <i class="fa fa-envelope"></i> registrar@northsouth.edu<p></p>
</div>
	
		
	<script>
		var map;
		function initMap() {
			var North={lat: 23.8151, lng: 90.4256};
			map = new google.maps.Map(document.getElementById('map'), {
				center: North,
				zoom:500,
				
			});
			marker = new google.maps.Marker({
            map,
            position: North ,
           });
		
 
		}
	</script>
	<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyDNZBlybaYyReciNIVhH0Xxp239aOfkDiM&callback=initMap" async defer></script>
	
</body>
</html>