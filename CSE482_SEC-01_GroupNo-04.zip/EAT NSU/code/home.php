<?php include('part-front/menu.php')?>

<!DOCTYPE html>
<html>
<head>
  
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<script>
function showUser(str) {
  if (str=="") {
    document.getElementById("txtHint").innerHTML="";
    return;
  }
  var xmlhttp=new XMLHttpRequest();
  xmlhttp.onreadystatechange=function() {
    if (this.readyState==4 && this.status==200) {
      document.getElementById("txtHint").innerHTML=this.responseText;
    }
  }
  xmlhttp.open("GET","getuser.php?q="+str,true);
  xmlhttp.send();
}
</script>
</head>
<body>

<form>
    <!-- fOOD sEARCH Section Starts Here -->
    <section class="food-search text-center">
        <div class="container">
        <div class="w3-container w3-center w3-animate-left">
  <b style="color: #d2384f" class='fail' id="txtHint" ><h1><b>EAT NSU</b></h1></b>
  <br>
  </div>
            <form action="<?php echo SITEURL; ?>student/getuser.php" method="POST">
            <div name="users" onchange="showUser(this.value)">
            <input type="search" name="search" placeholder="Search for Food.." required>
            
            <input type="submit" name="submit" value="Search" class="btn btn-primary">
</div>
<br>
<?php include('part-front/footer.php')?>
            </form>

        </div>
    </section>
    <!-- fOOD sEARCH Section Ends Here -->


<br>

<div class="w3-container w3-center w3-animate-left">
  <b style="color: Red" class='fail' id="txtHint" ><h1><b></b></h1></b>
 
  

  
</div>

</body>
</html>



   

